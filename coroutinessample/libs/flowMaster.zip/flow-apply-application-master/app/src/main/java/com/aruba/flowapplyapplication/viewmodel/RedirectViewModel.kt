package com.aruba.flowapplyapplication.viewmodel

import android.view.View
import androidx.lifecycle.ViewModel
import androidx.navigation.NavController
import com.aruba.flowapplyapplication.R

/**
 * Created by aruba on 2021/9/19.
 */
class RedirectViewModel() : ViewModel() {
    var controller: NavController? = null


    fun toFlowDown(v: View) {
        controller?.navigate(R.id.action_homeFragment_to_flowDownloadFragment)
    }

    fun toRoom(v: View) {
        controller?.navigate(R.id.action_homeFragment_to_roomFragment)
    }

    fun toRetrofit(v: View) {
        controller?.navigate(R.id.action_homeFragment_to_articleFragment)
    }

    fun toStateFlow(v: View) {
        controller?.navigate(R.id.action_homeFragment_to_stateFlowFragment)
    }

    fun toSharedFlow(v: View) {
        controller?.navigate(R.id.action_homeFragment_to_sharedFlowFragment)
    }
}