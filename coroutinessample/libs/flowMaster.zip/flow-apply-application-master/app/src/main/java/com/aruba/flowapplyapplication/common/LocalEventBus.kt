package com.aruba.flowapplyapplication.common

import kotlinx.coroutines.flow.MutableSharedFlow

/**
 * Created by aruba on 2021/9/21.
 */
object LocalEventBus {
    val event = MutableSharedFlow<Event>()

    suspend fun postEvent(e: Event) {
        event.emit(e)
    }

}

data class Event(val timestamp: Long)