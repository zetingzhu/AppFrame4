package com.aruba.flowapplyapplication

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.aruba.flowapplyapplication.databinding.FragmentFlowDownBinding
import com.aruba.flowapplyapplication.viewmodel.DownloadViewModel

class FlowDownloadFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val fragmentFlowDownBinding = DataBindingUtil.inflate<FragmentFlowDownBinding>(
            layoutInflater,
            R.layout.fragment_flow_down,
            container,
            false
        )

        val downloadViewModel = ViewModelProvider(
            this,
            ViewModelProvider.AndroidViewModelFactory(requireActivity().application)
        ).get(DownloadViewModel::class.java)
        fragmentFlowDownBinding.downloadViewModel = downloadViewModel
        fragmentFlowDownBinding.lifecycleOwner = this;

        return fragmentFlowDownBinding.root
    }

}