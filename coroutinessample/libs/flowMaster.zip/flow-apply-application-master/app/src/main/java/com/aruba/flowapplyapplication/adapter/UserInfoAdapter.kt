package com.aruba.flowapplyapplication.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.aruba.flowapplyapplication.R
import com.aruba.flowapplyapplication.database.entity.UserInfo
import com.aruba.flowapplyapplication.databinding.ItemUserinfoBinding

/**
 * Created by aruba on 2021/9/20.
 */
class UserInfoAdapter() : RecyclerView.Adapter<UserInfoAdapter.MyViewHolder>() {
    private var data = ArrayList<UserInfo>()

    class MyViewHolder(val binding: ItemUserinfoBinding) : RecyclerView.ViewHolder(binding.root)

    fun setData(data: List<UserInfo>) {
        this.data.clear()
        this.data.addAll(data)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding: ItemUserinfoBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.item_userinfo,
            parent, false
        )

        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.binding.userInfo = data[position]
    }

    override fun getItemCount(): Int {
        return data.size
    }
}