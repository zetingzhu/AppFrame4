package com.aruba.flowapplyapplication.download

import java.io.File

/**
 * 下载状态
 * Created by aruba on 2021/9/19.
 */
sealed class DownloadStatus {
    data class Progress(val progress: Int) : DownloadStatus()
    data class Err(val t: Throwable) : DownloadStatus()
    data class Done(val file: File) : DownloadStatus()
}