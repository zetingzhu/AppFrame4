package com.aruba.flowapplyapplication

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.aruba.flowapplyapplication.databinding.FragmentSharedFlowBinding
import com.aruba.flowapplyapplication.viewmodel.SharedFlowViewModel

class SharedFlowFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: FragmentSharedFlowBinding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_shared_flow,
            container, false
        )

        val sharedFlowViewModel = ViewModelProvider(
            this,
            ViewModelProvider.AndroidViewModelFactory(requireActivity().application)
        ).get(SharedFlowViewModel::class.java)
        binding.sharedFlowViewModel = sharedFlowViewModel
        
        return binding.root
    }

}