package com.aruba.flowapplyapplication.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.aruba.flowapplyapplication.database.entity.UserInfo
import kotlinx.coroutines.flow.Flow

/**
 * Created by aruba on 2021/9/20.
 */
@Dao
interface UserInfoDao {
    //id重复的替换
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(userInfo: UserInfo)

    //返回Flow，由于Flow需要使用collect，该函数为挂起函数，所以不需要加suspend了
    @Query("SELECT * FROM userinfo")
    fun getUserInfoList(): Flow<List<UserInfo>>
}