package com.aruba.flowapplyapplication

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.aruba.flowapplyapplication.adapter.UserInfoAdapter
import com.aruba.flowapplyapplication.database.MyDatabase
import com.aruba.flowapplyapplication.databinding.FragmentRoomBinding
import com.aruba.flowapplyapplication.viewmodel.UserInfoViewModel
import kotlinx.coroutines.flow.collect

class RoomFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        //初始化数据库
        MyDatabase.init(requireContext())
        
        val inflate = DataBindingUtil.inflate<FragmentRoomBinding>(
            layoutInflater,
            R.layout.fragment_room,
            container,
            false
        )

        //实例化ViewModel
        val userInfoViewModel = ViewModelProvider(
            this,
            ViewModelProvider.AndroidViewModelFactory(requireActivity().application)
        ).get(UserInfoViewModel::class.java)
        inflate.userInfoViewModel = userInfoViewModel
        inflate.recyclerview.adapter = UserInfoAdapter()
        inflate.recyclerview.layoutManager = LinearLayoutManager(context)
        inflate.lifecycleOwner = viewLifecycleOwner

        //开启协程对数据库的表进行监听
        lifecycleScope.launchWhenCreated {
            //每当UserInfo表发生变化，Flow都会把UserInfo列表发射出去，那么我们
            //在collect中就可以获取到
            userInfoViewModel.getUserInfo().collect {
                (inflate.recyclerview.adapter as UserInfoAdapter).setData(it)
            }
        }
        return inflate.root
    }

}