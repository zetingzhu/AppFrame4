package com.aruba.flowapplyapplication.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.aruba.flowapplyapplication.database.dao.UserInfoDao
import com.aruba.flowapplyapplication.database.entity.UserInfo

private const val DB_NAME: String = "my.db"

/**
 * Created by aruba on 2021/9/20.
 */
@Database(entities = [UserInfo::class], version = 1, exportSchema = false)
abstract class MyDatabase : RoomDatabase() {

    abstract fun getUserDao(): UserInfoDao

    companion object {
        private var instance: MyDatabase? = null

        fun getInstance(): MyDatabase {
            checkNotNull(instance) { "init has not been called" }
            return instance as MyDatabase
        }

        fun init(context: Context) {
            synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context,
                    MyDatabase::class.java, DB_NAME
                ).build().let { instance = it }
            }
        }
    }
}