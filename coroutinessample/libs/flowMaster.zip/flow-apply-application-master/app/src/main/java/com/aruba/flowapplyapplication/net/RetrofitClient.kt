package com.aruba.flowapplyapplication.net

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Created by aruba on 2021/9/21.
 */
object RetrofitClient {
    private val instance: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("http://192.168.0.118:8080/kotlinstudyserver/")
            .client(OkHttpClient.Builder().build())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    fun getApi(): Api {
        return instance.create(Api::class.java)
    }
}