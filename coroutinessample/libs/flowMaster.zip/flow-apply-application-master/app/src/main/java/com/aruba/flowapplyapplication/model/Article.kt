package com.aruba.flowapplyapplication.model

data class Article(val id: Int, val text: String)
