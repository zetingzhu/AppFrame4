package com.aruba.flowapplyapplication.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.lifecycle.*
import com.aruba.flowapplyapplication.download.DownloadManager
import com.aruba.flowapplyapplication.download.DownloadStatus
import com.aruba.flowapplyapplication.download.DownloadStatus.Progress
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File

/**
 * Created by aruba on 2021/9/19.
 */
class DownloadViewModel(val context: Application) : AndroidViewModel(context) {
    private var progressData = MutableLiveData<Int>()
    val progress = progressData

    private val url: String = "http://10.254.219.178:8080/test.rar"

    fun downloadClick(v: View) {
        viewModelScope.launch {
            progressData.value = 0
            val file = File(context.getExternalFilesDir(null), "test.rar")
            DownloadManager.download(url, file).collect {
                when (it) {
                    is Progress -> {
                        Log.i("progress", "progress: $it.progress")
                        progressData.value = it.progress
                    }
                    is DownloadStatus.Done -> {
                        progressData.value = 100
                        Toast.makeText(context, "下载完成", Toast.LENGTH_SHORT).show()
                    }
                    is DownloadStatus.Err ->
                        Toast.makeText(context, it.toString(), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}