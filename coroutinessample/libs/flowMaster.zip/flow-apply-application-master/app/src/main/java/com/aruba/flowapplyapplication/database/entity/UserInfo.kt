package com.aruba.flowapplyapplication.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Created by aruba on 2021/9/20.
 */
@Entity
data class UserInfo(
    @PrimaryKey val id: Int,
    var userName: String,
    var age: Int
)