package com.aruba.flowapplyapplication.net

import com.aruba.flowapplyapplication.model.Article
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Created by aruba on 2021/9/21.
 */
interface Api {
    
    @GET("article")
    suspend fun searchArticles(
        @Query("key") key: String
    ): List<Article>
    
}