package com.aruba.flowapplyapplication.viewmodel

import android.view.View
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aruba.flowapplyapplication.common.Event
import com.aruba.flowapplyapplication.common.LocalEventBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch

/**
 * Created by aruba on 2021/9/21.
 */
class SharedFlowViewModel : ViewModel() {
    private lateinit var job: Job
    
    fun start(v: View) {
        job = viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                LocalEventBus.postEvent(Event(System.currentTimeMillis()))
            }
        }
    }

    fun stop(v: View) {
        job.cancel()
    }
}