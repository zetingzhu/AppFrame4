package com.aruba.flowapplyapplication

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.aruba.flowapplyapplication.databinding.FragmentStateFlowBinding
import com.aruba.flowapplyapplication.viewmodel.StateFlowViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class StateFlowFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding: FragmentStateFlowBinding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_state_flow,
            container,
            false
        )

        val stateFlowViewModel = ViewModelProvider(
            this,
            ViewModelProvider.AndroidViewModelFactory(requireActivity().application)
        ).get(StateFlowViewModel::class.java)
//        lifecycleScope.launch {
//            stateFlowViewModel.stateFlow.collect {
//                binding.textView2.text = it.toString()
//            }
//        }
        binding.stateFlowViewModel = stateFlowViewModel
        binding.lifecycleOwner = viewLifecycleOwner

        return binding.root
    }

}